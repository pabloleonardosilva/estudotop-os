import { NextResponse } from "next/server";
import { Resend } from "resend";
import React from "react";
import { pdf } from "@react-pdf/renderer";
import { supabaseAdmin } from "../../../../lib/supabaseAdmin";
import OSDocument from "../../../components/pdf/OSDocument";

export const runtime = "nodejs";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const {
      osId,
      osNumber,
      professor,
      disciplina,
      arquivos,
      tempo,
      link,
      observacoes,
      operador,
    } = body;

    const { data: osCompleta, error: osError } = await supabaseAdmin
      .from("service_orders")
      .select(
        `
        *,
        teachers:teacher_id (name),
        subjects:subject_id (name)
      `
      )
      .eq("os_number", osNumber)
      .single();

    if (osError || !osCompleta) {
      return NextResponse.json(
        { error: "Não foi possível carregar a OS para gerar o PDF." },
        { status: 500 }
      );
    }

    const pdfBuffer = await pdf(
      React.createElement(OSDocument, { os: osCompleta })
    ).toBuffer();

    const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    const osLink = osId ? `${appUrl}/os/${osId}` : `${appUrl}/os`;

    const { error } = await resend.emails.send({
      from: "onboarding@resend.dev",
      to: ["pabloleonardo.silva@gmail.com"],
      subject: `🆕 OS ${osNumber} criada`,
      html: `
        <div style="font-family: Arial, sans-serif; line-height:1.5;">
          <h2 style="color:#f97316;">Nova Ordem de Serviço</h2>

          <hr/>

          <p><strong>🆔 OS:</strong> ${osNumber}</p>
          <p><strong>👨‍🏫 Professor:</strong> ${professor}</p>
          <p><strong>📚 Disciplina:</strong> ${disciplina}</p>
          <p><strong>📁 Arquivos:</strong> ${arquivos}</p>
          <p><strong>⏱ Tempo:</strong> ${tempo || "-"}</p>
          <p><strong>👤 Operador:</strong> ${operador}</p>

          <hr/>

          <p><strong>🔗 Drive:</strong></p>
          <p>${link || "-"}</p>

          <hr/>

          <p><strong>📝 Observações:</strong></p>
          <p>${observacoes || "-"}</p>

          <p style="margin-top:24px;">
            <a href="${osLink}" 
               style="display:inline-block;padding:12px 18px;background:#f97316;color:white;border-radius:10px;text-decoration:none;font-weight:bold;">
              Abrir OS no sistema
            </a>
          </p>
        </div>
      `,
      attachments: [
        {
          filename: `OS-${osNumber}.pdf`,
          content: pdfBuffer,
        },
      ],
    });

    if (error) {
      await supabaseAdmin
        .from("service_orders")
        .update({
          email_status: "error",
          email_error: error.message,
        })
        .eq("os_number", osNumber);

      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    await supabaseAdmin
      .from("service_orders")
      .update({
        email_status: "sent",
        email_error: null,
        email_sent_at: new Date().toISOString(),
      })
      .eq("os_number", osNumber);

    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json(
      { error: err.message || "Erro ao enviar email" },
      { status: 500 }
    );
  }
}