"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  CalendarDays,
  ClipboardList,
  Clock,
  FileVideo,
  Plus,
  RotateCcw,
  Search,
  Trash2,
} from "lucide-react";
import { supabase } from "../../lib/supabase";
import { useAuth } from "../contexts/AuthContext";
import SystemModal from "../components/SystemModal";
import PageBackground from "../components/ui/PageBackground";
import PageHeader from "../components/ui/PageHeader";
import PremiumButton from "../components/ui/PremiumButton";
import PremiumCard from "../components/ui/PremiumCard";
import PremiumSelect from "../components/ui/PremiumSelect";
import {
  PremiumTable,
  PremiumTableBody,
  PremiumTableCell,
  PremiumTableHead,
  PremiumTableHeader,
  PremiumTableRow,
} from "../components/ui/PremiumTable";

export default function ConsultarOS() {
  const { profile } = useAuth();
  const isAdmin = profile?.role === "admin";

  const [osList, setOsList] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [subjects, setSubjects] = useState<any[]>([]);

  const [filtroStatus, setFiltroStatus] = useState("");
  const [filtroProfessor, setFiltroProfessor] = useState("");
  const [filtroDisciplina, setFiltroDisciplina] = useState("");
  const [filtroPeriodo, setFiltroPeriodo] = useState("");
  const [dataInicial, setDataInicial] = useState("");
  const [dataFinal, setDataFinal] = useState("");

  const [modal, setModal] = useState<any>({
    open: false,
    title: "",
    message: "",
    type: "info",
    showCancel: false,
    confirmText: "Confirmar",
    cancelText: "Cancelar",
    onConfirm: null,
    onCancel: null,
  });

  useEffect(() => {
    buscarOS();
    buscarFiltros();
  }, [
    filtroStatus,
    filtroProfessor,
    filtroDisciplina,
    filtroPeriodo,
    dataInicial,
    dataFinal,
  ]);

  function fecharModal() {
    setModal({
      open: false,
      title: "",
      message: "",
      type: "info",
      showCancel: false,
      confirmText: "Confirmar",
      cancelText: "Cancelar",
      onConfirm: null,
      onCancel: null,
    });
  }

  function abrirModal(config: any) {
    setModal({
      open: true,
      title: config.title || "",
      message: config.message || "",
      type: config.type || "info",
      showCancel: config.showCancel || false,
      confirmText: config.confirmText || "Confirmar",
      cancelText: config.cancelText || "Cancelar",
      onConfirm: config.onConfirm || fecharModal,
      onCancel: config.onCancel || fecharModal,
    });
  }

  async function buscarOS() {
    let query = supabase
      .from("service_orders")
      .select(
        `
        *,
        teachers:teacher_id (
          id,
          name
        ),
        subjects:subject_id (
          id,
          name
        )
      `
      )
      .order("created_at", { ascending: false });

    if (filtroStatus) query = query.eq("status", filtroStatus);
    if (filtroProfessor) query = query.eq("teacher_id", filtroProfessor);
    if (filtroDisciplina) query = query.eq("subject_id", filtroDisciplina);

    const hoje = new Date();

    if (filtroPeriodo === "hoje") {
      const inicio = new Date();
      inicio.setHours(0, 0, 0, 0);

      const fim = new Date();
      fim.setHours(23, 59, 59, 999);

      query = query
        .gte("created_at", inicio.toISOString())
        .lte("created_at", fim.toISOString());
    }

    if (filtroPeriodo === "ultimos_7_dias") {
      const inicio = new Date();
      inicio.setDate(hoje.getDate() - 6);
      inicio.setHours(0, 0, 0, 0);

      const fim = new Date();
      fim.setHours(23, 59, 59, 999);

      query = query
        .gte("created_at", inicio.toISOString())
        .lte("created_at", fim.toISOString());
    }

    if (filtroPeriodo === "este_mes") {
      const inicio = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
      inicio.setHours(0, 0, 0, 0);

      const fim = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0);
      fim.setHours(23, 59, 59, 999);

      query = query
        .gte("created_at", inicio.toISOString())
        .lte("created_at", fim.toISOString());
    }

    if (filtroPeriodo === "personalizado") {
      if (dataInicial) {
        const inicio = new Date(`${dataInicial}T00:00:00`);
        query = query.gte("created_at", inicio.toISOString());
      }

      if (dataFinal) {
        const fim = new Date(`${dataFinal}T23:59:59`);
        query = query.lte("created_at", fim.toISOString());
      }
    }

    const { data, error } = await query;

    if (error) {
      console.error("Erro ao buscar OS:", error);

      abrirModal({
        title: "Erro ao carregar OS",
        message: "Não foi possível carregar as ordens de serviço.",
        type: "error",
        confirmText: "Entendi",
      });

      return;
    }

    setOsList(data || []);
  }

  async function buscarFiltros() {
    const { data: teachersData } = await supabase
      .from("teachers")
      .select("*")
      .order("name");

    const { data: subjectsData } = await supabase
      .from("subjects")
      .select("*")
      .order("name");

    setTeachers(teachersData || []);
    setSubjects(subjectsData || []);
  }

  function limparFiltros() {
    setFiltroStatus("");
    setFiltroProfessor("");
    setFiltroDisciplina("");
    setFiltroPeriodo("");
    setDataInicial("");
    setDataFinal("");
  }

  function formatarData(data: string) {
    if (!data) return "-";

    return new Date(data).toLocaleString("pt-BR", {
      dateStyle: "short",
      timeStyle: "short",
    });
  }

  function nomeStatus(status: string) {
    if (status === "pendente") return "Pendente";
    if (status === "editando") return "Em edição";
    if (status === "concluido") return "Concluído";
    return status || "-";
  }

  function estiloStatus(status: string) {
    if (status === "pendente") {
      return "bg-amber-50 text-amber-700 ring-amber-200";
    }

    if (status === "editando") {
      return "bg-blue-50 text-blue-700 ring-blue-200";
    }

    if (status === "concluido") {
      return "bg-emerald-50 text-emerald-700 ring-emerald-200";
    }

    return "bg-slate-100 text-slate-700 ring-slate-200";
  }

  function minutosParaHoras(minutos: number) {
    const h = Math.floor(minutos / 60);
    const m = minutos % 60;

    return `${h}h ${String(m).padStart(2, "0")}min`;
  }

  function nomeProfessor(os: any) {
    return os.teachers?.name || os.professor_name || "-";
  }

  function nomeDisciplina(os: any) {
    return os.subjects?.name || os.subject_name || "-";
  }

  function solicitarExcluirOS(os: any) {
    abrirModal({
      title: "Excluir OS?",
      message: `Tem certeza que deseja excluir a OS ${os.os_number}? Essa ação não poderá ser desfeita.`,
      type: "warning",
      showCancel: true,
      confirmText: "Sim, excluir",
      cancelText: "Cancelar",
      onConfirm: async () => {
        fecharModal();
        await excluirOS(os.id);
      },
      onCancel: fecharModal,
    });
  }

  async function excluirOS(id: string) {
    const { error } = await supabase.from("service_orders").delete().eq("id", id);

    if (error) {
      abrirModal({
        title: "Erro ao excluir",
        message: "Não foi possível excluir esta OS.",
        type: "error",
        confirmText: "Entendi",
      });
      return;
    }

    await buscarOS();

    abrirModal({
      title: "OS excluída",
      message: "A ordem de serviço foi excluída com sucesso.",
      type: "success",
      confirmText: "OK",
    });
  }

  const totalOS = osList.length;

  const totalArquivos = osList.reduce(
    (total, os) => total + Number(os.file_count || 0),
    0
  );

  const totalMinutos = osList.reduce(
    (total, os) => total + Number(os.total_video_minutes || 0),
    0
  );

  return (
    <PageBackground>
      <PageHeader
        title="Ordens de serviço"
        description="Consulte, filtre, acompanhe e gerencie as ordens de serviço do estúdio."
        action={
          <Link href="/os/nova">
            <PremiumButton icon={<Plus size={18} />}>Nova OS</PremiumButton>
          </Link>
        }
      />

      <PremiumCard
        title="Filtros"
        description="Refine a listagem por professor, disciplina, status ou período."
        icon={<Search size={21} />}
        action={
          <PremiumButton
            variant="secondary"
            icon={<RotateCcw size={16} />}
            onClick={limparFiltros}
          >
            Limpar
          </PremiumButton>
        }
      >
        <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
          <PremiumSelect
            value={filtroProfessor}
            onChange={(e: any) => setFiltroProfessor(e.target.value)}
          >
            <option value="">Todos os professores</option>
            {teachers.map((teacher) => (
              <option key={teacher.id} value={teacher.id}>
                {teacher.name}
              </option>
            ))}
          </PremiumSelect>

          <PremiumSelect
            value={filtroDisciplina}
            onChange={(e: any) => setFiltroDisciplina(e.target.value)}
          >
            <option value="">Todas as disciplinas</option>
            {subjects.map((subject) => (
              <option key={subject.id} value={subject.id}>
                {subject.name}
              </option>
            ))}
          </PremiumSelect>

          <PremiumSelect
            value={filtroStatus}
            onChange={(e: any) => setFiltroStatus(e.target.value)}
          >
            <option value="">Todos os status</option>
            <option value="pendente">Pendente</option>
            <option value="editando">Em edição</option>
            <option value="concluido">Concluído</option>
          </PremiumSelect>

          <PremiumSelect
            value={filtroPeriodo}
            onChange={(e: any) => {
              setFiltroPeriodo(e.target.value);
              setDataInicial("");
              setDataFinal("");
            }}
          >
            <option value="">Todos os períodos</option>
            <option value="hoje">Hoje</option>
            <option value="ultimos_7_dias">Últimos 7 dias</option>
            <option value="este_mes">Este mês</option>
            <option value="personalizado">Personalizado</option>
          </PremiumSelect>
        </div>

        {filtroPeriodo === "personalizado" && (
          <div className="mt-4 grid grid-cols-1 gap-3 rounded-2xl border border-orange-200 bg-orange-50/60 p-4 md:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-medium text-orange-700">
                Data inicial
              </label>
              <input
                type="date"
                value={dataInicial}
                onChange={(e) => setDataInicial(e.target.value)}
                className="h-12 w-full rounded-2xl border border-orange-200 bg-white px-4 text-sm text-slate-700 outline-none transition focus:border-orange-400 focus:ring-4 focus:ring-orange-100"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-orange-700">
                Data final
              </label>
              <input
                type="date"
                value={dataFinal}
                onChange={(e) => setDataFinal(e.target.value)}
                className="h-12 w-full rounded-2xl border border-orange-200 bg-white px-4 text-sm text-slate-700 outline-none transition focus:border-orange-400 focus:ring-4 focus:ring-orange-100"
              />
            </div>
          </div>
        )}
      </PremiumCard>

      {isAdmin && (
        <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-3">
          <MetricCard
            icon={<ClipboardList size={20} />}
            title="Total de OS"
            value={totalOS}
            detail="Resultado dos filtros aplicados"
          />

          <MetricCard
            icon={<FileVideo size={20} />}
            title="Total de arquivos"
            value={totalArquivos}
            detail="Arquivos nas OS filtradas"
          />

          <MetricCard
            icon={<Clock size={20} />}
            title="Tempo total"
            value={minutosParaHoras(totalMinutos)}
            detail="Soma dos tempos filtrados"
          />
        </div>
      )}

      <div className="mt-5">
        <PremiumCard
          title="Ordens de serviço"
          description={
            isAdmin
              ? "Clique no número da OS para abrir os detalhes. Use a lixeira para excluir."
              : "Clique no número da OS para abrir os detalhes."
          }
          icon={<CalendarDays size={21} />}
        >
          <PremiumTable>
            <PremiumTableHead>
              <tr>
                <PremiumTableHeader>OS</PremiumTableHeader>
                <PremiumTableHeader>Envio</PremiumTableHeader>
                <PremiumTableHeader>Professor</PremiumTableHeader>
                <PremiumTableHeader>Disciplina</PremiumTableHeader>
                <PremiumTableHeader>Arquivos</PremiumTableHeader>

                {isAdmin && <PremiumTableHeader>Tempo</PremiumTableHeader>}

                <PremiumTableHeader>Conclusão</PremiumTableHeader>
                <PremiumTableHeader>Status</PremiumTableHeader>

                {isAdmin && (
                  <PremiumTableHeader align="right">Ações</PremiumTableHeader>
                )}
              </tr>
            </PremiumTableHead>

            <PremiumTableBody>
              {osList.map((os) => (
                <PremiumTableRow key={os.id}>
                  <PremiumTableCell>
                    <Link
                      href={`/os/${os.id}`}
                      className="font-semibold text-slate-950 underline-offset-4 transition hover:text-orange-600 hover:underline"
                    >
                      {os.os_number}
                    </Link>
                  </PremiumTableCell>

                  <PremiumTableCell>{formatarData(os.created_at)}</PremiumTableCell>

                  <PremiumTableCell>
                    <span className="font-medium text-slate-800">
                      {nomeProfessor(os)}
                    </span>
                  </PremiumTableCell>

                  <PremiumTableCell>{nomeDisciplina(os)}</PremiumTableCell>

                  <PremiumTableCell>{os.file_count || 0}</PremiumTableCell>

                  {isAdmin && (
                    <PremiumTableCell>
                      {os.total_video_time || "-"}
                    </PremiumTableCell>
                  )}

                  <PremiumTableCell>
                    {os.completed_at ? formatarData(os.completed_at) : "-"}
                  </PremiumTableCell>

                  <PremiumTableCell>
                    <span
                      className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ring-1 ${estiloStatus(
                        os.status
                      )}`}
                    >
                      {nomeStatus(os.status)}
                    </span>
                  </PremiumTableCell>

                  {isAdmin && (
                    <PremiumTableCell align="right">
                      <button
                        type="button"
                        onClick={() => solicitarExcluirOS(os)}
                        className="inline-flex items-center justify-center rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs font-medium text-red-600 transition hover:bg-red-100"
                        title="Excluir OS"
                      >
                        <Trash2 size={15} />
                      </button>
                    </PremiumTableCell>
                  )}
                </PremiumTableRow>
              ))}

              {osList.length === 0 && (
                <tr>
                  <td
                    colSpan={isAdmin ? 9 : 7}
                    className="px-4 py-10 text-center text-sm text-slate-500"
                  >
                    Nenhuma OS encontrada para os filtros selecionados.
                  </td>
                </tr>
              )}
            </PremiumTableBody>
          </PremiumTable>
        </PremiumCard>
      </div>

      <SystemModal {...modal} />
    </PageBackground>
  );
}

function MetricCard({
  icon,
  title,
  value,
  detail,
}: {
  icon: React.ReactNode;
  title: string;
  value: any;
  detail: string;
}) {
  return (
    <div className="relative overflow-hidden rounded-[1.5rem] border border-white/80 bg-white p-5 shadow-sm ring-1 ring-slate-200/60">
      <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-gradient-to-br from-orange-500 to-amber-500 opacity-10 blur-xl" />

      <div className="relative flex items-start justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-400">
            {title}
          </p>

          <p className="mt-3 text-2xl font-medium tracking-tight text-slate-950">
            {value}
          </p>

          <p className="mt-1 text-xs text-slate-400">{detail}</p>
        </div>

        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500 to-amber-500 text-slate-950 shadow-lg shadow-orange-500/20">
          {icon}
        </div>
      </div>
    </div>
  );
}