"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  ArrowLeft,
  BookOpen,
  CalendarDays,
  CheckCircle2,
  Clock,
  Edit3,
  ExternalLink,
  FileText,
  Files,
  Link as LinkIcon,
  Printer,
  FileDown,
  UserRound,
} from "lucide-react";
import { supabase } from "../../../lib/supabase";
import PageBackground from "../../components/ui/PageBackground";
import PageHeader from "../../components/ui/PageHeader";
import PremiumButton from "../../components/ui/PremiumButton";
import PremiumCard from "../../components/ui/PremiumCard";

export default function DetalheOS() {
  const { id } = useParams();
  const [os, setOs] = useState<any>(null);

  useEffect(() => {
    carregarOS();
  }, []);

  async function carregarOS() {
    const { data, error } = await supabase
      .from("service_orders")
      .select(
        `
        *,
        teachers:teacher_id (id, name),
        subjects:subject_id (id, name)
      `
      )
      .eq("id", id)
      .single();

    if (error) {
      console.error("Erro ao carregar OS:", error);
      return;
    }

    setOs(data);
  }

  function formatarData(data: string) {
    if (!data) return "-";

    return new Date(data).toLocaleString("pt-BR", {
      dateStyle: "short",
      timeStyle: "short",
    });
  }

  function nomeStatus(status: string) {
    if (status === "pendente") return "Pendente";
    if (status === "editando") return "Em edição";
    if (status === "concluido") return "Concluído";
    return status || "-";
  }

  function estiloStatus(status: string) {
    if (status === "pendente")
      return "bg-amber-50 text-amber-700 ring-amber-200";
    if (status === "editando")
      return "bg-blue-50 text-blue-700 ring-blue-200";
    if (status === "concluido")
      return "bg-emerald-50 text-emerald-700 ring-emerald-200";
    return "bg-slate-100 text-slate-700 ring-slate-200";
  }

  function nomeProfessor() {
    return os?.teachers?.name || os?.professor_name || "-";
  }

  function nomeDisciplina() {
    return os?.subjects?.name || os?.subject_name || "-";
  }

  if (!os) {
    return (
      <PageBackground>
        <div className="rounded-[2rem] border border-white/80 bg-white p-8 text-sm text-slate-500 shadow-sm">
          Carregando OS...
        </div>
      </PageBackground>
    );
  }

  return (
    <PageBackground>
      <PageHeader
        title={os.os_number}
        description="Detalhamento completo da ordem de serviço."
        action={
          <div className="flex flex-wrap gap-2">
            <Link href="/os">
              <PremiumButton variant="secondary" icon={<ArrowLeft size={17} />}>
                Voltar
              </PremiumButton>
            </Link>

            <Link href={`/os/${os.id}/editar`}>
              <PremiumButton variant="secondary" icon={<Edit3 size={17} />}>
                Editar
              </PremiumButton>
            </Link>

            <Link href={`/os/${os.id}/print`}>
              <PremiumButton icon={<Printer size={17} />}>
                Imprimir
              </PremiumButton>
            </Link>

            <Link href={`/os/${os.id}/pdf`}>
              <PremiumButton icon={<FileDown size={17} />}>
                Gerar PDF
              </PremiumButton>
            </Link>
          </div>
        }
      />

      {/* STATUS */}
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <span
          className={`inline-flex rounded-full px-4 py-2 text-xs font-semibold ring-1 ${estiloStatus(
            os.status
          )}`}
        >
          {nomeStatus(os.status)}
        </span>

        <span className="rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-medium text-slate-500 shadow-sm">
          Criada em {formatarData(os.created_at)}
        </span>
      </div>

      {/* CARDS */}
      <section className="grid grid-cols-1 gap-4 md:grid-cols-4">
        <InfoCard
          icon={<CalendarDays size={20} />}
          label="Data de envio"
          value={formatarData(os.created_at)}
        />

        <InfoCard
          icon={<Files size={20} />}
          label="Arquivos"
          value={os.file_count || 0}
        />

        <InfoCard
          icon={<Clock size={20} />}
          label="Tempo total"
          value={os.total_video_time || "-"}
        />

        <InfoCard
          icon={<CheckCircle2 size={20} />}
          label="Conclusão"
          value={os.completed_at ? formatarData(os.completed_at) : "-"}
        />
      </section>

      {/* DETALHES */}
      <section className="mt-5 grid grid-cols-1 gap-5 lg:grid-cols-2">
        <PremiumCard
          title="Professor e disciplina"
          description="Dados principais da gravação."
          icon={<UserRound size={21} />}
        >
          <DetailItem
            icon={<UserRound size={18} />}
            label="Professor"
            value={nomeProfessor()}
          />

          <DetailItem
            icon={<BookOpen size={18} />}
            label="Disciplina"
            value={nomeDisciplina()}
          />
        </PremiumCard>

        <PremiumCard
          title="Produção"
          description="Dados técnicos da OS."
          icon={<Files size={21} />}
        >
          <DetailItem
            icon={<Files size={18} />}
            label="Arquivos"
            value={os.file_count || 0}
          />

          <DetailItem
            icon={<Clock size={18} />}
            label="Tempo (min)"
            value={os.total_video_minutes || 0}
          />
        </PremiumCard>
      </section>

      {/* DRIVE */}
      <section className="mt-5">
        <PremiumCard
          title="Google Drive"
          description="Acesso aos arquivos enviados."
          icon={<LinkIcon size={21} />}
        >
          {os.drive_link ? (
            <a
              href={os.drive_link}
              target="_blank"
              className="flex items-start gap-3 rounded-2xl border border-orange-200 bg-orange-50/60 p-4 text-sm text-orange-700 hover:bg-orange-100"
            >
              <LinkIcon size={18} />
              <span className="break-all">{os.drive_link}</span>
              <ExternalLink size={16} className="ml-auto" />
            </a>
          ) : (
            <p className="text-sm text-slate-500">
              Nenhum link informado.
            </p>
          )}
        </PremiumCard>
      </section>

      {/* OBS */}
      <section className="mt-5">
        <PremiumCard
          title="Observações"
          description="Detalhes adicionais da OS."
          icon={<FileText size={21} />}
        >
          <p className="text-sm text-slate-600">
            {os.notes || "Nenhuma observação registrada."}
          </p>
        </PremiumCard>
      </section>
    </PageBackground>
  );
}

/* COMPONENTES */

function InfoCard({ icon, label, value }: any) {
  return (
    <div className="rounded-2xl border bg-white p-5 shadow-sm">
      <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-orange-500 text-white">
        {icon}
      </div>

      <p className="text-xs text-slate-400">{label}</p>
      <p className="text-lg font-semibold text-slate-900">{value}</p>
    </div>
  );
}

function DetailItem({ icon, label, value }: any) {
  return (
    <div className="flex gap-3 py-2">
      <div className="text-slate-400">{icon}</div>

      <div>
        <p className="text-xs text-slate-400">{label}</p>
        <p className="text-sm font-semibold text-slate-900">{value}</p>
      </div>
    </div>
  );
}