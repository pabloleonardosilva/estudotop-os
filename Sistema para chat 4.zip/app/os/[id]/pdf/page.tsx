"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  PDFDownloadLink,
} from "@react-pdf/renderer";
import { supabase } from "../../../../lib/supabase";

export default function GerarPDF() {
  const { id } = useParams();
  const [os, setOs] = useState<any>(null);

  useEffect(() => {
    carregarOS();
  }, []);

  async function carregarOS() {
    const { data, error } = await supabase
      .from("service_orders")
      .select(`
        *,
        teachers:teacher_id (name),
        subjects:subject_id (name)
      `)
      .eq("id", id)
      .single();

    if (error) {
      console.error("Erro ao carregar OS:", error);
      return;
    }

    setOs(data);
  }

  if (!os) {
    return (
      <main className="min-h-screen bg-slate-100 p-10 text-sm text-slate-500">
        Carregando PDF...
      </main>
    );
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-100 p-10">
      <PDFDownloadLink
        document={<OSDocument os={os} />}
        fileName={`OS-${os.os_number}.pdf`}
        className="rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-orange-500/20"
      >
        Baixar PDF da OS
      </PDFDownloadLink>
    </main>
  );
}

function OSDocument({ os }: any) {
  const professor = os.teachers?.name || os.professor_name || "-";
  const disciplina = os.subjects?.name || os.subject_name || "-";

  function nomeStatus(status: string) {
    if (status === "pendente") return "Pendente";
    if (status === "editando") return "Em edição";
    if (status === "concluido") return "Concluído";
    return status || "-";
  }

  function formatarData(data: string) {
    if (!data) return "-";

    return new Date(data).toLocaleString("pt-BR", {
      dateStyle: "short",
      timeStyle: "short",
    });
  }

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* TOPO */}
        <View style={styles.header}>
          <View>
            <Text style={styles.brand}>ESTUDOTOP OS</Text>
            <Text style={styles.title}>Ordem de Serviço</Text>
            <Text style={styles.subtitle}>
              Documento de controle de produção audiovisual
            </Text>
          </View>

          <View style={styles.osBox}>
            <Text style={styles.osLabel}>Nº DA OS</Text>
            <Text style={styles.osNumber}>{os.os_number}</Text>
          </View>
        </View>

        {/* STATUS */}
        <View style={styles.statusRow}>
          <Text style={styles.statusBadge}>{nomeStatus(os.status)}</Text>
          <Text style={styles.dateText}>
            Emitido em {formatarData(new Date().toISOString())}
          </Text>
        </View>

        {/* DADOS PRINCIPAIS */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Dados principais</Text>

          <View style={styles.grid}>
            <Info label="Professor" value={professor} />
            <Info label="Disciplina" value={disciplina} />
            <Info label="Data de envio" value={formatarData(os.created_at)} />
            <Info
              label="Data de conclusão"
              value={os.completed_at ? formatarData(os.completed_at) : "-"}
            />
          </View>
        </View>

        {/* PRODUÇÃO */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Dados da produção</Text>

          <View style={styles.grid}>
            <Info label="Quantidade de arquivos" value={os.file_count || 0} />
            <Info label="Tempo total" value={os.total_video_time || "-"} />
            <Info
              label="Tempo em minutos"
              value={os.total_video_minutes || 0}
            />
            <Info label="Status" value={nomeStatus(os.status)} />
          </View>
        </View>

        {/* DRIVE */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Link do Google Drive</Text>

          <View style={styles.textBox}>
            <Text style={styles.bodyText}>
              {os.drive_link || "Nenhum link informado."}
            </Text>
          </View>
        </View>

        {/* OBSERVAÇÕES */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Observações</Text>

          <View style={styles.notesBox}>
            <Text style={styles.bodyText}>
              {os.notes || "Nenhuma observação registrada."}
            </Text>
          </View>
        </View>

        {/* ASSINATURAS */}
        <View style={styles.signatures}>
          <View style={styles.signatureBox}>
            <View style={styles.signatureLine} />
            <Text style={styles.signatureText}>Responsável pela edição</Text>
          </View>

          <View style={styles.signatureBox}>
            <View style={styles.signatureLine} />
            <Text style={styles.signatureText}>Conferência / Aprovação</Text>
          </View>
        </View>

        {/* RODAPÉ */}
        <View style={styles.footer}>
          <Text>Sistema EstudoTOP OS</Text>
          <Text>{os.os_number}</Text>
        </View>
      </Page>
    </Document>
  );
}

function Info({ label, value }: { label: string; value: any }) {
  return (
    <View style={styles.infoItem}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={styles.infoValue}>{String(value || "-")}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    padding: 36,
    fontSize: 10,
    fontFamily: "Helvetica",
    color: "#0f172a",
    backgroundColor: "#ffffff",
  },

  header: {
    backgroundColor: "#080b12",
    borderRadius: 14,
    padding: 22,
    marginBottom: 18,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  brand: {
    fontSize: 9,
    letterSpacing: 3,
    color: "#fb923c",
    fontWeight: "bold",
    marginBottom: 6,
  },

  title: {
    fontSize: 24,
    color: "#ffffff",
    fontWeight: "bold",
  },

  subtitle: {
    marginTop: 6,
    fontSize: 10,
    color: "#cbd5e1",
  },

  osBox: {
    backgroundColor: "#f97316",
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 14,
    minWidth: 100,
    alignItems: "center",
  },

  osLabel: {
    fontSize: 7,
    letterSpacing: 1.5,
    color: "#111827",
    fontWeight: "bold",
  },

  osNumber: {
    marginTop: 4,
    fontSize: 15,
    color: "#111827",
    fontWeight: "bold",
  },

  statusRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 18,
  },

  statusBadge: {
    backgroundColor: "#ffedd5",
    color: "#9a3412",
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 999,
    fontSize: 9,
    fontWeight: "bold",
  },

  dateText: {
    fontSize: 9,
    color: "#64748b",
  },

  section: {
    marginBottom: 18,
  },

  sectionTitle: {
    fontSize: 10,
    textTransform: "uppercase",
    letterSpacing: 1.6,
    color: "#64748b",
    fontWeight: "bold",
    marginBottom: 8,
  },

  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },

  infoItem: {
    width: "48%",
    border: "1 solid #e2e8f0",
    borderRadius: 10,
    padding: 12,
    marginBottom: 8,
    backgroundColor: "#f8fafc",
  },

  infoLabel: {
    fontSize: 8,
    color: "#64748b",
    textTransform: "uppercase",
    letterSpacing: 1,
    marginBottom: 5,
  },

  infoValue: {
    fontSize: 11,
    color: "#0f172a",
    fontWeight: "bold",
  },

  textBox: {
    border: "1 solid #fed7aa",
    backgroundColor: "#fff7ed",
    borderRadius: 10,
    padding: 12,
  },

  notesBox: {
    minHeight: 90,
    border: "1 solid #e2e8f0",
    backgroundColor: "#f8fafc",
    borderRadius: 10,
    padding: 12,
  },

  bodyText: {
    fontSize: 10,
    color: "#334155",
    lineHeight: 1.5,
  },

  signatures: {
    marginTop: 28,
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 24,
  },

  signatureBox: {
    width: "45%",
  },

  signatureLine: {
    borderTop: "1 solid #94a3b8",
    marginBottom: 6,
  },

  signatureText: {
    fontSize: 8,
    color: "#64748b",
    textAlign: "center",
  },

  footer: {
    position: "absolute",
    bottom: 24,
    left: 36,
    right: 36,
    borderTop: "1 solid #e2e8f0",
    paddingTop: 8,
    flexDirection: "row",
    justifyContent: "space-between",
    fontSize: 8,
    color: "#94a3b8",
  },
});