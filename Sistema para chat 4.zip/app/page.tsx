"use client";

import Link from "next/link";
import {
  ArrowRight,
  BarChart3,
  BookOpen,
  ClipboardList,
  GraduationCap,
  Plus,
} from "lucide-react";

export default function Home() {
  const cards = [
    {
      titulo: "Cadastrar OS",
      subtitulo: "Novo envio de vídeos.",
      icone: <Plus size={21} />,
      href: "/os/nova",
      cor: "from-blue-500 to-indigo-500",
    },
    {
      titulo: "Consultar OS",
      subtitulo: "Pendências e conclusões.",
      icone: <ClipboardList size={21} />,
      href: "/os",
      cor: "from-slate-800 to-slate-950",
    },
    {
      titulo: "Dashboard",
      subtitulo: "Métricas e produtividade.",
      icone: <BarChart3 size={21} />,
      href: "/dashboard",
      cor: "from-emerald-500 to-green-500",
    },
    {
      titulo: "Professores",
      subtitulo: "Gerenciar professores.",
      icone: <GraduationCap size={21} />,
      href: "/professores",
      cor: "from-purple-500 to-pink-500",
    },
    {
      titulo: "Disciplinas",
      subtitulo: "Gerenciar disciplinas.",
      icone: <BookOpen size={21} />,
      href: "/disciplinas",
      cor: "from-orange-500 to-amber-500",
    },
  ];

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-100 via-slate-100 to-orange-50/40 px-6 py-7">
      <section className="mx-auto max-w-7xl">
        <header className="relative overflow-hidden rounded-[2rem] border border-white/70 bg-white/85 p-8 shadow-sm ring-1 ring-slate-200/60 backdrop-blur">
          <div className="absolute right-0 top-0 h-40 w-40 translate-x-14 -translate-y-16 rounded-full bg-orange-500/10 blur-2xl" />
          <div className="absolute bottom-0 right-32 h-32 w-32 translate-y-16 rounded-full bg-amber-400/10 blur-2xl" />

          <div className="relative">
            <p className="text-xs font-semibold uppercase tracking-[0.26em] text-orange-500">
              EstudoTOP OS
            </p>

            <h1 className="mt-3 text-4xl font-medium tracking-tight text-slate-950">
              Painel inicial
            </h1>

            <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-500">
              Acesse rapidamente os principais módulos do sistema de ordens de
              serviço, produção e acompanhamento.
            </p>
          </div>
        </header>

        <section className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5">
          {cards.map((card) => (
            <Link key={card.titulo} href={card.href}>
              <div className="group relative flex min-h-[230px] flex-col overflow-hidden rounded-[1.7rem] border border-white/80 bg-white p-5 shadow-sm ring-1 ring-slate-200/60 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl">
                <div
                  className={`absolute -right-12 -top-12 h-32 w-32 rounded-full bg-gradient-to-br ${card.cor} opacity-10 blur-2xl transition group-hover:opacity-20`}
                />

                <div className="relative">
                  <div
                    className={`flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br ${card.cor} text-white shadow-lg transition duration-300 group-hover:scale-110`}
                  >
                    {card.icone}
                  </div>
                </div>

                <div className="relative mt-7 flex-1">
                  <h2 className="text-base font-semibold tracking-tight text-slate-950">
                    {card.titulo}
                  </h2>

                  <p className="mt-2 text-xs leading-5 text-slate-500">
                    {card.subtitulo}
                  </p>
                </div>

                <div className="relative mt-5 border-t border-slate-200 pt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-400">
                      Acessar
                    </span>

                    <span className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-500 shadow-sm transition group-hover:border-orange-400 group-hover:bg-orange-500 group-hover:text-slate-950">
                      <ArrowRight size={15} />
                    </span>
                  </div>
                </div>

                <div
                  className={`absolute bottom-0 left-0 h-[3px] w-0 bg-gradient-to-r ${card.cor} transition-all duration-300 group-hover:w-full`}
                />
              </div>
            </Link>
          ))}
        </section>
      </section>
    </main>
  );
}